'use client'

import { useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Search, X } from 'lucide-react'

/* ── Components page header with search ──────────────────────── */
export function ComponentsHeader({ search, onSearch, totalCount }) {
  const inputRef = useRef(null)

  // Debounce: call onSearch 350ms after user stops typing
  const timerRef = useRef(null)

  const handleChange = (e) => {
    const val = e.target.value
    clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => onSearch(val), 350)
    // Update input value immediately (uncontrolled feel)
    if (inputRef.current) inputRef.current.value = val
  }

  const handleClear = () => {
    if (inputRef.current) inputRef.current.value = ''
    clearTimeout(timerRef.current)
    onSearch('')
  }

  useEffect(() => () => clearTimeout(timerRef.current), [])

  return (
    <div className="mb-8 sm:mb-10">
      {/* Title block */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-6"
      >
        <p
          className="text-xs font-semibold uppercase tracking-widest mb-2"
          style={{ color: 'var(--red)', fontFamily: 'var(--font-display)' }}
        >
          Component Catalog
        </p>
        <h1
          className="text-3xl sm:text-4xl font-bold mb-2"
          style={{ fontFamily: 'var(--font-display)', letterSpacing: '-0.02em' }}
        >
          Explore Components
        </h1>
        <p className="text-sm sm:text-base" style={{ color: 'var(--text-2)' }}>
          Browse real-time priced PC parts — filtered by type, brand, and compatibility.
          {totalCount != null && (
            <span style={{ color: 'var(--text-3)' }}>
              {' '}({totalCount.toLocaleString()} results)
            </span>
          )}
        </p>
      </motion.div>

      {/* Search bar */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="relative"
      >
        <Search
          size={16}
          className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
          style={{ color: 'var(--text-3)' }}
        />
        <input
          ref={inputRef}
          type="text"
          placeholder="Search by name, brand, or spec…"
          onChange={handleChange}
          defaultValue={search}
          className="w-full h-12 pl-11 pr-11 rounded-xl text-sm outline-none transition-all duration-200"
          style={{
            background:   'var(--surface-2)',
            border:       '1px solid var(--border)',
            color:        'var(--text-1)',
            fontFamily:   'var(--font-display)',
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = 'rgba(255,59,31,0.4)'
            e.currentTarget.style.boxShadow   = '0 0 0 3px rgba(255,59,31,0.08)'
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = 'var(--border)'
            e.currentTarget.style.boxShadow   = 'none'
          }}
        />
        {search && (
          <button
            onClick={handleClear}
            className="absolute right-4 top-1/2 -translate-y-1/2"
            style={{ color: 'var(--text-3)' }}
          >
            <X size={15} />
          </button>
        )}
      </motion.div>
    </div>
  )
}