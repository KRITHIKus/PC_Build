'use client'

import { motion } from 'framer-motion'
import { TrendingUp, Clock, Store, AlertCircle } from 'lucide-react'
import { useGetLatestPriceQuery } from '@/services/pricingApi'
import { formatPrice }           from '@/lib/utils'

/* ── Skeleton ────────────────────────────────────────────────── */
function PriceSkeleton() {
  return (
    <div className="flex flex-col gap-3">
      <div className="animate-pulse h-8 w-32 rounded-lg" style={{ background: 'rgba(255,59,31,0.08)' }} />
      <div className="animate-pulse h-4 w-48 rounded" style={{ background: 'rgba(255,255,255,0.05)' }} />
      <div className="animate-pulse h-4 w-36 rounded" style={{ background: 'rgba(255,255,255,0.04)' }} />
    </div>
  )
}

/* ── Format checkedAt date nicely ────────────────────────────── */
function formatChecked(dateStr) {
  if (!dateStr) return null
  try {
    return new Date(dateStr).toLocaleString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })
  } catch {
    return null
  }
}

/* ── Component Pricing Section ───────────────────────────────── */
export function ComponentPricing({ componentId, estimatedPrice }) {
  const {
    data,
    isLoading,
    isError,
    refetch,
  } = useGetLatestPriceQuery(
    { componentId, region: 'Karnataka' },
    { skip: !componentId }
  )

  // Normalise: API may return { price, sourceName, checkedAt } directly or nested
  const priceData = data?.pricing ?? data?.data ?? data

  return (
    <div
      className="rounded-2xl p-5"
      style={{ background: 'var(--surface-1)', border: '1px solid var(--border)' }}
    >
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp size={15} style={{ color: 'var(--red)' }} />
        <h3
          className="text-sm font-bold uppercase tracking-wider"
          style={{ fontFamily: 'var(--font-display)', color: 'var(--text-2)' }}
        >
          Live Pricing — Karnataka
        </h3>
      </div>

      {isLoading && <PriceSkeleton />}

      {isError && (
        <div className="flex flex-col gap-3">
          {/* Fallback to estimated if live fetch fails */}
          {estimatedPrice != null && (
            <div>
              <p className="text-xs mb-1" style={{ color: 'var(--text-3)' }}>Estimated Price</p>
              <p
                className="text-2xl font-bold"
                style={{ fontFamily: 'var(--font-display)', color: 'var(--text-1)' }}
              >
                {formatPrice(estimatedPrice)}
              </p>
            </div>
          )}
          <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-3)' }}>
            <AlertCircle size={12} />
            <span>Live pricing unavailable.</span>
            <button
              onClick={refetch}
              className="underline transition-colors"
              style={{ color: 'var(--red)' }}
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {!isLoading && !isError && (
        <div className="flex flex-col gap-4">
          {/* Live price (if available) */}
          {priceData?.price != null ? (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <p className="text-xs mb-1" style={{ color: 'var(--text-3)', fontFamily: 'var(--font-display)' }}>
                Current Market Price
              </p>
              <p
                className="text-3xl font-bold mb-0.5"
                style={{ fontFamily: 'var(--font-display)', color: 'var(--text-1)' }}
              >
                {formatPrice(priceData.price)}
              </p>
              {/* Source */}
              {priceData.sourceName && (
                <div className="flex items-center gap-1.5 text-xs" style={{ color: 'var(--text-3)' }}>
                  <Store size={11} />
                  <span>{priceData.sourceName}</span>
                </div>
              )}
              {/* Checked at */}
              {priceData.checkedAt && (
                <div className="flex items-center gap-1.5 text-xs mt-1" style={{ color: 'var(--text-3)' }}>
                  <Clock size={11} />
                  <span>{formatChecked(priceData.checkedAt)}</span>
                </div>
              )}
            </motion.div>
          ) : (
            /* No live price — fall back to estimated */
            estimatedPrice != null && (
              <div>
                <p className="text-xs mb-1" style={{ color: 'var(--text-3)' }}>Estimated Price</p>
                <p
                  className="text-2xl font-bold"
                  style={{ fontFamily: 'var(--font-display)', color: 'var(--text-1)' }}
                >
                  {formatPrice(estimatedPrice)}
                </p>
                <p className="text-xs mt-1" style={{ color: 'var(--text-3)' }}>
                  Live pricing not available for this region.
                </p>
              </div>
            )
          )}

          {/* Estimated comparison if both available */}
          {priceData?.price != null && estimatedPrice != null && (
            <div
              className="pt-3"
              style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}
            >
              <p className="text-xs" style={{ color: 'var(--text-3)' }}>
                Estimated:{' '}
                <span style={{ color: 'var(--text-2)' }}>{formatPrice(estimatedPrice)}</span>
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}