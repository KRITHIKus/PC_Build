import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  user:            null,
  token:           null,
  isAuthenticated: false,
  isLoading:       false,
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setCredentials(state, { payload }) {
      state.user            = payload.user
      state.token           = payload.token
      state.isAuthenticated = true
    },
    clearCredentials(state) {
      state.user            = null
      state.token           = null
      state.isAuthenticated = false
    },
    setAuthLoading(state, { payload }) {
      state.isLoading = payload
    },
    updateUser(state, { payload }) {
      state.user = { ...state.user, ...payload }
    },
  },
})

export const {
  setCredentials,
  clearCredentials,
  setAuthLoading,
  updateUser,
} = authSlice.actions

export default authSlice.reducer

// Selectors
export const selectCurrentUser     = (state) => state.auth.user
export const selectToken           = (state) => state.auth.token
export const selectIsAuthenticated = (state) => state.auth.isAuthenticated
export const selectAuthLoading     = (state) => state.auth.isLoading
export const selectIsAdmin         = (state) => state.auth.user?.role === 'admin'
