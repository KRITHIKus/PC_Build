import { configureStore, combineReducers } from '@reduxjs/toolkit'
import {
  persistStore,
  persistReducer,
  FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER,
} from 'redux-persist'
import storage from 'redux-persist/lib/storage'

import authReducer from './authSlice'
import uiReducer   from './uiSlice'
import { baseApi } from '@/services/baseApi'

// ── Persist configs ─────────────────────────────────────────────
// Only auth and minimal ui state are persisted.
// RTK Query cache is intentionally NOT persisted.

const authPersistConfig = {
  key:       'auth',
  storage,
  whitelist: ['user', 'token', 'isAuthenticated'],
}

const uiPersistConfig = {
  key:       'ui',
  storage,
  whitelist: ['sidebarOpen'],
}

// ── Root reducer ─────────────────────────────────────────────────
const rootReducer = combineReducers({
  auth: persistReducer(authPersistConfig, authReducer),
  ui:   persistReducer(uiPersistConfig,   uiReducer),
  [baseApi.reducerPath]: baseApi.reducer,
})

// ── Store ─────────────────────────────────────────────────────────
export const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }).concat(baseApi.middleware),
  devTools: process.env.NODE_ENV !== 'production',
})

export const persistor = persistStore(store)
