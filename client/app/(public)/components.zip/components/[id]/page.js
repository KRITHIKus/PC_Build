'use client'

import { use } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  ArrowLeft, Package, AlertCircle, RefreshCw,
} from 'lucide-react'
import { useGetComponentByIdQuery } from '@/services/componentsApi'
import { ComponentFallbackVisual } from '@/components/components/ComponentFallbackVisual'
import { ComponentPricing }        from '@/components/components/ComponentPricing'
import { ComponentSpecs, ComponentCompatibility, StockBadge } from '@/components/components/ComponentSpecs'

/* ── Type badge ──────────────────────────────────────────────── */
function TypeBadge({ type }) {
  return (
    <span
      className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider"
      style={{
        background: 'rgba(255,59,31,0.1)',
        border:     '1px solid rgba(255,59,31,0.22)',
        color:      'var(--red)',
        fontFamily: 'var(--font-display)',
      }}
    >
      {type}
    </span>
  )
}

/* ── Loading skeleton ────────────────────────────────────────── */
function DetailSkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
      {/* Left */}
      <div
        className="rounded-2xl animate-pulse"
        style={{ height: '380px', background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)' }}
      />
      {/* Right */}
      <div className="flex flex-col gap-5">
        <div className="animate-pulse h-5 w-20 rounded-lg" style={{ background: 'rgba(255,59,31,0.08)' }} />
        <div className="animate-pulse h-8 w-3/4 rounded-lg" style={{ background: 'rgba(255,255,255,0.06)' }} />
        <div className="animate-pulse h-5 w-1/3 rounded" style={{ background: 'rgba(255,255,255,0.04)' }} />
        <div className="animate-pulse h-24 w-full rounded-xl" style={{ background: 'rgba(255,255,255,0.04)' }} />
        <div className="animate-pulse h-32 w-full rounded-2xl" style={{ background: 'rgba(255,255,255,0.04)' }} />
      </div>
    </div>
  )
}

/* ── Error state ─────────────────────────────────────────────── */
function DetailError({ onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center py-28 text-center">
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
        style={{ background: 'rgba(255,59,31,0.08)', border: '1px solid rgba(255,59,31,0.18)' }}
      >
        <AlertCircle size={28} style={{ color: 'var(--red)' }} strokeWidth={1.5} />
      </div>
      <h2 className="text-xl font-semibold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
        Component not found
      </h2>
      <p className="text-sm mb-6 max-w-xs" style={{ color: 'var(--text-2)' }}>
        This component may have been removed or the link is incorrect.
      </p>
      <div className="flex items-center gap-3">
        <Link
          href="/components"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium"
          style={{
            background: 'var(--surface-2)',
            border:     '1px solid var(--border)',
            color:      'var(--text-1)',
            fontFamily: 'var(--font-display)',
          }}
        >
          Back to catalog
        </Link>
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium"
          style={{
            background: 'rgba(255,59,31,0.1)',
            border:     '1px solid rgba(255,59,31,0.25)',
            color:      'var(--red)',
            fontFamily: 'var(--font-display)',
          }}
        >
          <RefreshCw size={14} />
          Retry
        </button>
      </div>
    </div>
  )
}

/* ── Component Detail Page ───────────────────────────────────── */
export default function ComponentDetailPage({ params }) {
  // Next.js 15+ — params is a Promise
  const { id } = params

  const { data, isLoading, isError, refetch } = useGetComponentByIdQuery(id, { skip: !id })

  // Normalise response shape
  const component = data?.component ?? data?.data ?? data

  return (
    <div className="container-app py-10 sm:py-14">

      {/* Back link */}
      <motion.div
        initial={{ opacity: 0, x: -12 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.35 }}
        className="mb-8"
      >
        <Link
          href="/components"
          className="inline-flex items-center gap-2 text-sm font-medium transition-colors"
          style={{ color: 'var(--text-2)', fontFamily: 'var(--font-display)' }}
          onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--text-1)' }}
          onMouseLeave={(e) => { e.currentTarget.style.color = 'var(--text-2)' }}
        >
          <ArrowLeft size={15} strokeWidth={2} />
          Back to Components
        </Link>
      </motion.div>

      {/* Loading */}
      {isLoading && <DetailSkeleton />}

      {/* Error */}
      {isError && <DetailError onRetry={refetch} />}

      {/* Content */}
      {!isLoading && !isError && component && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.45 }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 mb-10">

            {/* ── Left: image / fallback ─────────────────────── */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
              className="relative flex items-center justify-center rounded-2xl overflow-hidden"
              style={{
                minHeight:   '320px',
                background:  'var(--surface-2)',
                border:      '1px solid var(--border)',
              }}
            >
              {component.imageUrl ? (
                <div className="relative w-full h-full" style={{ minHeight: '320px' }}>
                  <Image
                    src={component.imageUrl}
                    alt={component.name}
                    fill
                    className="object-contain p-8"
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    priority
                  />
                </div>
              ) : (
                <div className="w-48 h-48">
                  <ComponentFallbackVisual type={component.type} size="lg" />
                </div>
              )}

              {/* Top glow line */}
              <div
                className="absolute top-0 left-0 right-0 h-px pointer-events-none"
                style={{ background: 'linear-gradient(90deg, transparent, rgba(255,59,31,0.4), transparent)' }}
              />
            </motion.div>

            {/* ── Right: info ────────────────────────────────── */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.55, delay: 0.07, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col gap-5"
            >
              {/* Badges row */}
              <div className="flex items-center gap-3 flex-wrap">
                {component.type && <TypeBadge type={component.type} />}
                <StockBadge inStock={component.inStock} />
              </div>

              {/* Name */}
              <div>
                <h1
                  className="text-2xl sm:text-3xl font-bold leading-tight mb-1"
                  style={{ fontFamily: 'var(--font-display)', letterSpacing: '-0.02em' }}
                >
                  {component.name}
                </h1>
                {component.brand && (
                  <p className="text-sm" style={{ color: 'var(--text-3)', fontFamily: 'var(--font-display)' }}>
                    by {component.brand}
                    {component.model ? ` · ${component.model}` : ''}
                  </p>
                )}
              </div>

              {/* Description */}
              {component.description && (
                <p
                  className="text-sm leading-relaxed"
                  style={{ color: 'var(--text-2)' }}
                >
                  {component.description}
                </p>
              )}

              {/* Pricing */}
              <ComponentPricing
                componentId={component._id}
                estimatedPrice={component.estimatedPrice}
              />

              {/* Quick action */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <Link
                  href="/build-lab"
                  className="flex-1 h-11 flex items-center justify-center gap-2 rounded-xl text-sm font-semibold transition-all duration-150"
                  style={{
                    background: 'linear-gradient(135deg,#ff4d33,#ff3b1f,#e11d2e)',
                    color:      '#fff',
                    fontFamily: 'var(--font-display)',
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.boxShadow = '0 0 20px rgba(255,59,31,0.45)' }}
                  onMouseLeave={(e) => { e.currentTarget.style.boxShadow = 'none' }}
                >
                  <Package size={15} />
                  Add to Build
                </Link>
                <Link
                  href="/compare"
                  className="flex-1 h-11 flex items-center justify-center gap-2 rounded-xl text-sm font-semibold transition-all duration-150"
                  style={{
                    background: 'var(--surface-2)',
                    border:     '1px solid var(--border)',
                    color:      'var(--text-1)',
                    fontFamily: 'var(--font-display)',
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.2)' }}
                  onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border)' }}
                >
                  Compare
                </Link>
              </div>
            </motion.div>
          </div>

          {/* ── Specs + Compatibility row ─────────────────────── */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-5"
          >
            <ComponentSpecs specs={component.specs ?? {}} />
            <ComponentCompatibility compatibility={component.compatibility ?? component.specs ?? {}} />
          </motion.div>
        </motion.div>
      )}

      {/* Not found (no error, no data) */}
      {!isLoading && !isError && !component && (
        <DetailError onRetry={refetch} />
      )}
    </div>
  )
}